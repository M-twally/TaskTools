package services;

public class Helper {
	 private int res;

	    public Helper (int n) {
	        this.res = n;
	    }

	    public int get_Result() {
	        return res;
	    }

	    public void set_Result(int number) {
	        this.res = number;
	    }

}
